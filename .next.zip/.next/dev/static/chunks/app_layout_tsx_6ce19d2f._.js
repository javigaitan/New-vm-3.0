(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1dff6_next_dist_client_b724c006._.js",
  "static/chunks/app_globals_71f961d1.css"
],
    source: "dynamic"
});
