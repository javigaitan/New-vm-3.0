__turbopack_load_page_chunks__("/_app", [
  "static/chunks/1dff6_next_dist_compiled_344d2ff4._.js",
  "static/chunks/1dff6_next_dist_shared_lib_233f3bf4._.js",
  "static/chunks/1dff6_next_dist_client_7a10b8a2._.js",
  "static/chunks/1dff6_next_dist_a10da97e._.js",
  "static/chunks/1dff6_next_app_4012ce45.js",
  "static/chunks/[next]_entry_page-loader_ts_77ab6b9d._.js",
  "static/chunks/76102_react-dom_44795136._.js",
  "static/chunks/node_modules__pnpm_7136f466._.js",
  "static/chunks/[root-of-the-server]__45f039c3._.js",
  "static/chunks/pages__app_2da965e7._.js",
  "static/chunks/turbopack-pages__app_273d1f63._.js"
])
