globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/1dff6_next_dist_compiled_344d2ff4._.js",
      "static/chunks/1dff6_next_dist_shared_lib_233f3bf4._.js",
      "static/chunks/1dff6_next_dist_client_7a10b8a2._.js",
      "static/chunks/1dff6_next_dist_a10da97e._.js",
      "static/chunks/1dff6_next_app_4012ce45.js",
      "static/chunks/[next]_entry_page-loader_ts_77ab6b9d._.js",
      "static/chunks/76102_react-dom_44795136._.js",
      "static/chunks/node_modules__pnpm_7136f466._.js",
      "static/chunks/[root-of-the-server]__45f039c3._.js",
      "static/chunks/pages__app_2da965e7._.js",
      "static/chunks/turbopack-pages__app_273d1f63._.js"
    ],
    "/_error": [
      "static/chunks/1dff6_next_dist_compiled_344d2ff4._.js",
      "static/chunks/1dff6_next_dist_shared_lib_06d0bfb5._.js",
      "static/chunks/1dff6_next_dist_client_7a10b8a2._.js",
      "static/chunks/1dff6_next_dist_bca72155._.js",
      "static/chunks/1dff6_next_error_6092d967.js",
      "static/chunks/[next]_entry_page-loader_ts_6c140a88._.js",
      "static/chunks/76102_react-dom_44795136._.js",
      "static/chunks/node_modules__pnpm_7136f466._.js",
      "static/chunks/[root-of-the-server]__092393de._.js",
      "static/chunks/pages__error_2da965e7._.js",
      "static/chunks/turbopack-pages__error_03325a16._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/1dff6_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f1d3f032._.js",
    "static/chunks/1dff6_next_dist_compiled_react-dom_987ad27f._.js",
    "static/chunks/1dff6_next_dist_compiled_react-server-dom-turbopack_b69c1d6b._.js",
    "static/chunks/1dff6_next_dist_compiled_next-devtools_index_b10aad90.js",
    "static/chunks/1dff6_next_dist_compiled_c5f28bd9._.js",
    "static/chunks/1dff6_next_dist_client_e3c2bcb2._.js",
    "static/chunks/1dff6_next_dist_4512f89c._.js",
    "static/chunks/69652_@swc_helpers_cjs_679851cc._.js",
    "static/chunks/_a0ff3932._.js",
    "static/chunks/turbopack-_8177140e._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];